This is the first assignment 
----------------------------


In order to run the project, you should have python3 installed.

first, move at the "src" folder, then execute the file app.py:
-----------------------------------------------------------------

$ cd src
$ python app.py 

(or python3 depending on your computer)
type that the command line or open the project with Pycharm or any other IDE.
(Personal opinion: pycharm is the best)
-----------------------------------------------------------------

Important: As I generate some files* in the training_set folder, 
please do not move nor delete that folder when you run the assignment.


* : Those files are the language models in JSON format.
