This is the last assignment
----------------------------


In order to run the project, you should have python3 installed.
(Important: In order to solve the CSP, I use the library python-constraint.
You can install it with the command line:

> pip install python-constraint


My IDE (pycharm) executes the project without any problems.
Please place yourself in the same directory as the assignment3.py file
in order to have no problem of path. 

> the file "constraints-definitions.json" must be placed in the same directory as "asignment3.py"

To execute the file from the terminal:
-----------------------------------------------------------------
$ python3 assignment3.py <input_file>

IMPORTANT: please name the COCA bigram file "bigrams.txt"