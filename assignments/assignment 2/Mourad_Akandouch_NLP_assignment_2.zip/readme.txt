This is the second assignment
----------------------------


In order to run the project, you should have python3 installed.
(Important: In order to parse the conllu format,
I use the conllu package which I think is not part of the vanilla python.

My IDE (pycharm) executes the project without any problems.

To execute the file from the terminal:
-----------------------------------------------------------------
$ python Parser.py

(but I think you need to install conllu package first)
